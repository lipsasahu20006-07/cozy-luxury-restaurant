const mongoose = require("mongoose");

const uri = "mongodb+srv://restaurantadmin:sahu30@restaurantdb.9acldgv.mongodb.net/restaurantDB?retryWrites=true&w=majority&appName=restaurantDB";

mongoose
  .connect(uri)
  .then(() => {
    console.log("✅ Connected successfully!");
    process.exit(0);
  })
  .catch((err) => {
    console.error("❌ Connection failed:");
    console.error(err);
    process.exit(1);
  });