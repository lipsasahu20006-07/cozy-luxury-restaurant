const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const dotenv = require("dotenv");
const reservationRoutes = require("./routes/reservationRoutes");

dotenv.config();
console.log("MONGO_URI =", process.env.MONGO_URI);
const app = express();

app.use(cors());
app.use(express.json());
app.use((req, res, next) => {
  console.log(req.method, req.url);
  next();
});
app.use("/api", reservationRoutes);


mongoose
  .connect(process.env.MONGO_URI)
  .then(() => {
    console.log("✅ Connected to MongoDB");
  })
  .catch((err) => {
    console.log("❌ MongoDB Connection Error:", err);
  });

app.get("/", (req, res) => {
  console.log("HOME ROUTE HIT");
  res.send("🎉 TEST BACKEND");
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});