const express = require("express");
const router = express.Router();
const Reservation = require("../models/Reservation");

router.post("/reserve", async (req, res) => {
  try {
    console.log(req.body);

    const reservation = new Reservation(req.body);
    await reservation.save();

    res.status(201).json({
      message: "Reservation saved successfully!",
      reservation,
    });
  } catch (error) {
    console.error(error);

    res.status(500).json({
      message: "Error saving reservation",
      error: error.message,
    });
  }
});

module.exports = router;